A Pen created at CodePen.io. You can find this one at https://codepen.io/hrtzt/pen/NPZKRN.

 This is a one page navigation with diferent sections and a pure CSS menu and transitions.